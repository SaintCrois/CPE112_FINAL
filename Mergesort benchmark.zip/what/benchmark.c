#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct betNode {
    char betType[10];    
    int inputNum[6];     
    int money;

    int action;  
    struct betNode *next;
} BetNode;

typedef struct gameNode {
    int cash;
    char name[100];
    BetNode *bet;
    BetNode *undoStack;
    struct gameNode *next;
} GameNode;

GameNode *head = NULL;

void loadData() {
    FILE *fp = fopen("member.csv", "r");
    if (fp == NULL) return;

    char line[100], name[100];
    int cash;
    while (fgets(line, sizeof(line), fp)) {
        sscanf(line, "%[^,],%d", name, &cash);
        insertEnd(&head, cash, name);
    }
    fclose(fp);
}

void insertEnd(GameNode **head, int cash, char namu[100]) 
{
    GameNode *newGameNode = (GameNode *)malloc(sizeof(GameNode));
    newGameNode->next = NULL;
    newGameNode->cash = cash;
    newGameNode->bet = NULL;
    newGameNode->undoStack= NULL;
    strcpy(newGameNode->name, namu);

    if (*head == NULL) 
    {
        *head = newGameNode;
        return;
    }

    GameNode *ptr = *head;

    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newGameNode;
}

GameNode* sortedMerge(GameNode* a, GameNode* b) {
    GameNode* result = NULL;

    if (a == NULL)
        return b;
    else if (b == NULL)
        return a;

    if (a->cash >= b->cash) {
        result = a;
        result->next = sortedMerge(a->next, b);
    } else {
        result = b;
        result->next = sortedMerge(a, b->next);
    }

    return result;
}

void frontBackSplit(GameNode* source, GameNode** frontRef, GameNode** backRef) {
    GameNode* fast;
    GameNode* slow;
    if (source == NULL || source->next == NULL) {
        *frontRef = source;
        *backRef = NULL;
        return;
    }

    slow = source;
    fast = source->next;
    while (fast != NULL) {
        fast = fast->next;
        if (fast != NULL) {
            slow = slow->next;
            fast = fast->next;
        }
    }
    *frontRef = source;
    *backRef = slow->next;
    slow->next = NULL;
}

void mergeSort(GameNode** headRef) {
    GameNode* head = *headRef;
    GameNode* a;
    GameNode* b;

    if (head == NULL || head->next == NULL)
        return;

    frontBackSplit(head, &a, &b);

    mergeSort(&a);
    mergeSort(&b);

    *headRef = sortedMerge(a, b);
}

int main() {
    clock_t start = clock();
    loadData();
    mergeSort(&head);
    clock_t end = clock();

    float time = (float)(end - start);
    printf("%f", time/CLOCKS_PER_SEC);
}